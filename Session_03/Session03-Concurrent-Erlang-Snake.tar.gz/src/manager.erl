-module(manager).

%%
%% Exported Functions
%%
-export([start/0]).

%%
%% API Functions
%%
start() ->
    Work = generated_work(),

    % start workers to process the work, use unreliable_worker:work/1
    Workers = [],

    wait_on_workers(Workers).

%%
%% Local Functions
%%
generated_work() ->
	[a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p].

wait_on_workers([]) ->
    io:fwrite("All Work Done~n");
wait_on_workers(Tasks) ->
    receive
        {'EXIT', Pid, Reason} ->
            io:fwrite("Pid ~w exited with reason: ~w~n", [Pid, Reason]),
            % Reason is either a result, or an exception. In case of an
            % exception, try again
            toDo; % edit here...
        SomethingElse ->
            io:fwrite("Something else: ~w~n", [SomethingElse])
    end.

