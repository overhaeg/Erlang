-module(hello_world).
-export([start/0, print/2]).

start() ->
    HelloWorld = "Hello World!",
    lists:map(fun printer/1, HelloWorld),
    timer:sleep(1000),
    io:nl().

printer(Char) ->
    spawn(?MODULE, print, [Char, random:uniform(500)]).

print(Char, Sleep) ->
    timer:sleep(Sleep),
    io:put_chars([Char]).
