package solutions;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class ConcurrencyInsteadOfPerformance extends JPanel implements
		ActionListener {

	final int MAX = 1000000;

	private ExecutorService executor;

	private JProgressBar progressBar;
	private JButton startButton;
	private JTextArea taskOutput;

	class Task implements Runnable {
		Task() {
		}

		public void run() {
			startButton.setEnabled(false);
			setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

			taskOutput.append(String
					.format("Found the following prime numbers:\n"));

			for (long i = 1; i < MAX; i++) {
				if (isPrime(i))
					taskOutput.append(String.format("%d ", i));
				// Optional: update progress bar
				progressBar.setValue((int) ((float)i / MAX * 100.0));
			}

			startButton.setEnabled(true);
			setCursor(null); // turn off the wait cursor
			taskOutput.append("Done!\n");
		}

		/**
		 * Returns true if num is prime.
		 */
		public boolean isPrime(long num) {
			boolean prime = true;
			long limit = (long) Math.sqrt(num);

			for (long i = 2; i <= limit; i++) {
				if (num % i == 0) {
					prime = false;
					break;
				}
			}

			return prime;
		}
	}

	public ConcurrencyInsteadOfPerformance() {
		super(new BorderLayout());

		executor = Executors.newCachedThreadPool();

		// Create the demo's UI.
		startButton = new JButton("Start");
		startButton.setActionCommand("start");
		startButton.addActionListener(this);

		progressBar = new JProgressBar(0, 100);
		progressBar.setValue(0);
		progressBar.setStringPainted(true);

		taskOutput = new JTextArea(15, 50);
		taskOutput.setMargin(new Insets(5, 5, 5, 5));
		taskOutput.setEditable(false);
		taskOutput.setLineWrap(true);
		taskOutput.setWrapStyleWord(true);

		JPanel panel = new JPanel();
		panel.add(startButton);
		panel.add(progressBar);

		add(panel, BorderLayout.PAGE_START);
		add(new JScrollPane(taskOutput), BorderLayout.CENTER);
		setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	}

	/**
	 * Invoked when start button is pressed. This runs in the UI thread.
	 */
	@Override
	public void actionPerformed(ActionEvent evt) {
		// Submit task to executor: the task will be started in another thread.
		executor.submit(new Task());
		// This returns immediately, while in the assignment the UI thread was
		// blocked until all prime numbers were computed.
	}

	/**
	 * Create the GUI and show it. As with all GUI code, this must run on the
	 * event-dispatching thread.
	 */
	private static void createAndShowGUI() {
		// Create and set up the window.
		JFrame frame = new JFrame(
				"Using threads for concurrency instead of performance in a GUI");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Create and set up the content pane.
		JComponent newContentPane = new ConcurrencyInsteadOfPerformance();
		newContentPane.setOpaque(true); // content panes must be opaque
		frame.setContentPane(newContentPane);

		// Display the window.
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}

	private static final long serialVersionUID = -6953327968929225182L;
}
