package solutions;

import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * The java.util.concurrent Hello World!
 * 
 * REMARK: HelloWorld is a JUnit test and can be executed as one.
 */
public class HelloWorld {

	/**
	 * This is a test that checks whether the string, which is split up and
	 * reassembled, is correct in the end.
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void itIsReallyGreatingTheWorld() throws InterruptedException {
		String helloWorld = "Hello World!";
		assertEquals(helloWorld, destructAndReconstruct(helloWorld));
	}

	/**
	 * This is where the magic happens, however, this code is perfectly fine.
	 * No modifications are required.
	 * 
	 * The input string is converted to a list of characters, and for each
	 * character a task is created and scheduled for concurrent execution. The
	 * tasks try to grab a character and put it into the result list.
	 * 
	 * A very standard situation, a problem is split into small sub-tasks
	 * working on shared data structures.
	 * 
	 * @param aString
	 * @return a copy of aString
	 * @throws InterruptedException
	 */
	String destructAndReconstruct(String aString) throws InterruptedException {
		// Create a service that executes tasks in parallel
		ExecutorService executor = Executors.newFixedThreadPool(4);

		// Prepare the lists
		final LinkedList<Character> list = new LinkedList<Character>();
		for (Character c : aString.toCharArray()) {
			list.add(c);
		}

		final LinkedList<Character> result = new LinkedList<Character>();

		// Create a task for each character
		for (int i = 0; i < aString.length(); i++) {
			executor.submit(new Task(list, result));
		}
		executor.shutdown(); // All tasks submitted, close executor

		// Await until everything is done
		executor.awaitTermination(100, TimeUnit.DAYS);

		// Re-assemble string
		String returnValue = "";
		for (Character c : result) {
			returnValue += c;
		}
		return returnValue;
	}

	/**
	 * This is the critical place!
	 * 
	 * Why? What is the fundamental thing done here?
	 * 
	 * Name the relevant concepts, and use the simplest possible solution to
	 * ensure that this method exhibits the expected behavior.
	 * 
	 * @param inputList
	 *            (Hint: Who owns me?)
	 * @param resultList
	 *            (Hint 2: Who owns me?)
	 */
	synchronized void processLists(LinkedList<Character> inputList,
			LinkedList<Character> resultList) {
		Character myChar = inputList.pop();

		System.out.print(myChar); // debug output

		resultList.add(myChar);
	}

	// A task that can be executed in parallel
	class Task implements Runnable {
		final LinkedList<Character> input;
		final LinkedList<Character> output;

		Task(final LinkedList<Character> in, final LinkedList<Character> out) {
			input = in;
			output = out;
		}

		public void run() {
			// This just increases the probability that you see the bug
			// never trust the scheduler!!!
			try {
				Thread.sleep(150);
			} catch (InterruptedException e) {
			}

			processLists(input, output);
		}
	}

	// Helper for debugging
	public static void main(String[] args) throws InterruptedException {
		new HelloWorld().itIsReallyGreatingTheWorld();
	}

}
